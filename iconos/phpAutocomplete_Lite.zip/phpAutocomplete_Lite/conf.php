<?php
define('PAC_PATH', '/phpAutocomplete_Lite');
define('DEBUG', false);

/******** DO NOT MODIFY ***********/
require_once('pac.php');
/**********************************/
?>