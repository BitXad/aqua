<?php
require_once("../conf.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>phpDatabaseForm - Simple Form Layout</title>
</head>
<body>

<?php
// when not using default single column layout, it is recommended to list the fields
// in the same order of to be displayed on the form, from top to bottom, left to right
$dbForm = new C_DatabaseForm("SELECT EmployeeID, LastName, Gender, BirthDate, ReportsTo, Notes FROM Employees", "EmployeeID", "Employees");

$dbForm -> load_form(9);
$dbForm -> set_form_dimension(600);  // set width to 500 for table template

$dbForm -> add_group_header("EmployeeID", "Basic Information");

$dbForm -> set_label("EmployeeID", "Employee ID");
$dbForm -> set_label("LastName", "Last Name");
$dbForm -> set_label("FirstName", "First Name");
$dbForm -> set_label("BirthDate", "DoB");

$dbForm -> set_readonly(array("EmployeeID")); // read only during edit. Does not apply to add new.
$dbForm -> set_required(array("LastName"));

$dbForm -> set_ctrltype('Notes', 'wysiwyg', 30, 40);
$dbForm -> set_ctrltype('Gender', 'radio', 'M:Male;F:Female');
$dbForm -> set_ctrltype("ReportsTo", "select", "SELECT EmployeeID, LastName FROM Employees");

$dbForm -> add_group_header("BirthDate", "Personal Information");

$dbForm -> set_placeholder('LastName', 'Employee\'s last name');
$dbForm -> set_placeholder('FirstName', 'Employee\'s first name');
$dbForm -> set_placeholder('BirthDate', 'Date of Birth');

$dbForm -> set_border("1px solid #888");

$dbForm -> display();
?>

<div style="text-align:center">
    <a href="complex_form.php">Complex form example</a>
</div>

</body>
</html>