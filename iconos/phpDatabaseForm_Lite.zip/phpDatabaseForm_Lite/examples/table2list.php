<html>
<head><title>test table2list</title></head>
<body>
<form name="FormPost" id="FrmGrid_employees" class="pdbf" onsubmit="return false;" style="width:640px;overflow:auto;position:relative;height:auto;">
<table id="TblGrid_employees" class="EditTable" cellspacing="0" cellpadding="0" border="0">
<tbody>
<tr id="FormError" style="display:none">
    <td class="ui-state-error" colspan="2"></td>
</tr>
<tr style="display:none" class="tinfo">
    <td class="topinfo" colspan="2"></td>
</tr>
<tr class="FormData">
    <td class="CaptionTD ui-widget-content" colspan="100%">
        <div class="form_group_header"><strong>Basic Info</strong></div>
    </td>
</tr>
<tr rowpos="1" class="FormData" id="tr_EmployeeID">
    <td class="CaptionTD">Employee ID</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="EmployeeID" name="EmployeeID" role="textbox" class="FormElement ui-widget-content ui-corner-all" readonly="readonly"></td>
</tr>
<tr rowpos="2" class="FormData leftHalf" id="tr_LastName">
    <td class="CaptionTD">Last Name</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" maxlength="8" id="LastName" name="LastName" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium" readonly="readonly"></td>
</tr>
<tr rowpos="3" class="FormData rightHalf" id="tr_FirstName">
    <td class="CaptionTD">First Name</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="FirstName" name="FirstName" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium" style="cursor: auto;"></td>
</tr>
<tr rowpos="4" class="FormData" id="tr_Gender">
    <td class="CaptionTD">Gender</td>
    <td class="DataTD">
        &nbsp;
                        <span class="FormElement">
                            <div class="input_list customelement" id="Gender" name="Gender"><input type="radio" id="Gender" name="Gender" value="M" checked="checked">Male<br><input type="radio" id="Gender" name="Gender" value="F">Female<br></div>
                        </span>
    </td>
</tr>
<tr style="display:none" rowpos="5" class="FormData" id="tr_Title">
    <td class="CaptionTD">Title</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" placeholder="official job title" id="Title" name="Title" role="textbox" class="FormElement ui-widget-content ui-corner-all"></td>
</tr>
<tr rowpos="6" class="FormData leftThird" id="tr_TitleOfCourtesy">
    <td class="CaptionTD">Suffix</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" placeholder="Mr., Ms., phD, Professor" id="TitleOfCourtesy" name="TitleOfCourtesy" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium"></td>
</tr>
<tr rowpos="7" class="FormData middleThird" id="tr_BirthDate">
    <td class="CaptionTD">BirthDate</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="BirthDate" name="BirthDate" role="textbox" class="FormElement ui-widget-content ui-corner-all hasDatepicker field text medium"><span id="_BirthDate_tooltip" class="tooltip_txt" original-title="Enter employee birth date"> <span class="tooltip_sym">(?)</span> </span></td>
</tr>
<tr rowpos="8" class="FormData rightThird" id="tr_HireDate">
    <td class="CaptionTD">HireDate</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="HireDate" name="HireDate" role="textbox" class="FormElement ui-widget-content ui-corner-all hasDatepicker field text medium"></td>
</tr>
<tr rowpos="9" class="FormData leftHalf" id="tr_SSN">
    <td class="CaptionTD">SSN # (if applicable)</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="SSN" name="SSN" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium"></td>
</tr>
<tr rowpos="10" class="FormData rightHalf" id="tr_ReportsTo">
    <td class="CaptionTD">Reports To</td>
    <td class="DataTD">
        &nbsp;
        <select role="select" id="ReportsTo" name="ReportsTo" size="1" class="FormElement ui-widget-content ui-corner-all field select medium">
            <option role="option" value="1">Davolio</option>
            <option role="option" value="3">Leverling</option>
            <option role="option" value="4">Peacock</option>
            <option role="option" value="5">Buchanan</option>
            <option role="option" value="7">King</option>
            <option role="option" value="8">Callahan</option>
            <option role="option" value="9">Dodsworth</option>
            <option role="option" value="29">Richard</option>
        </select>
    </td>
</tr>
<tr class="FormData">
    <td class="CaptionTD ui-widget-content" colspan="100%">
        <div class="form_group_header"><strong>Contact Info</strong></div>
    </td>
</tr>
<tr rowpos="11" class="FormData" id="tr_Email">
    <td class="CaptionTD">Email</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" placeholder="name@example.com" id="Email" name="Email" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium"></td>
</tr>
<tr rowpos="12" class="FormData leftFourth" id="tr_Address">
    <td class="CaptionTD">Address</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="Address" name="Address" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium"></td>
</tr>
<tr rowpos="13" class="FormData middleFourth" id="tr_City">
    <td class="CaptionTD">City</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="City" name="City" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium"></td>
</tr>
<tr rowpos="14" class="FormData middleFourth" id="tr_Region">
    <td class="CaptionTD">Region</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="Region" name="Region" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium"></td>
</tr>
<tr rowpos="15" class="FormData rightFourth" id="tr_PostalCode">
    <td class="CaptionTD">Postal Code</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="PostalCode" name="PostalCode" role="textbox" class="FormElement ui-widget-content ui-corner-all field text medium"></td>
</tr>
<tr rowpos="16" class="FormData" id="tr_Country">
<td class="CaptionTD">Country</td>
<td class="DataTD">
&nbsp;
<div class="select2-container FormElement ui-widget-content ui-corner-all" id="s2id_Country">
    <a href="javascript:void(0)" onclick="return false;" class="select2-choice" tabindex="-1">   <span class="select2-chosen">Aruba</span><abbr class="select2-search-choice-close"></abbr>   <span class="select2-arrow"><b></b></span></a><input class="select2-focusser select2-offscreen" type="text" id="s2id_autogen1">
    <div class="select2-drop select2-display-none select2-with-searchbox">
        <div class="select2-search">       <input type="text" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="select2-input">   </div>
        <ul class="select2-results">   </ul>
    </div>
</div>
<select role="select" id="Country" name="Country" size="1" class="FormElement ui-widget-content ui-corner-all select2-offscreen" tabindex="-1">
<option role="option" value="ABW">Aruba</option>
<option role="option" value="AFG">Afghanistan</option>
<option role="option" value="AGO">Angola</option>
<option role="option" value="AIA">Anguilla</option>
<option role="option" value="ALB">Albania</option>
<option role="option" value="AND">Andorra</option>
<option role="option" value="ANT">Netherlands Antilles</option>
<option role="option" value="ARE">United Arab Emirates</option>
<option role="option" value="ARG">Argentina</option>
<option role="option" value="ARM">Armenia</option>
<option role="option" value="ASM">American Samoa</option>
<option role="option" value="ATA">Antarctica</option>
<option role="option" value="ATF">French Southern territories</option>
<option role="option" value="ATG">Antigua and Barbuda</option>
<option role="option" value="AUS">Australia</option>
<option role="option" value="AUT">Austria</option>
<option role="option" value="AZE">Azerbaijan</option>
<option role="option" value="BDI">Burundi</option>
<option role="option" value="BEL">Belgium</option>
<option role="option" value="BEN">Benin</option>
<option role="option" value="BFA">Burkina Faso</option>
<option role="option" value="BGD">Bangladesh</option>
<option role="option" value="BGR">Bulgaria</option>
<option role="option" value="BHR">Bahrain</option>
<option role="option" value="BHS">Bahamas</option>
<option role="option" value="BIH">Bosnia and Herzegovina</option>
<option role="option" value="BLR">Belarus</option>
<option role="option" value="BLZ">Belize</option>
<option role="option" value="BMU">Bermuda</option>
<option role="option" value="BOL">Bolivia</option>
<option role="option" value="BRA">Brazil</option>
<option role="option" value="BRB">Barbados</option>
<option role="option" value="BRN">Brunei</option>
<option role="option" value="BTN">Bhutan</option>
<option role="option" value="BVT">Bouvet Island</option>
<option role="option" value="BWA">Botswana</option>
<option role="option" value="CAF">Central African Republic</option>
<option role="option" value="CAN">Canada</option>
<option role="option" value="CCK">Cocos (Keeling) Islands</option>
<option role="option" value="CHE">Switzerland</option>
<option role="option" value="CHL">Chile</option>
<option role="option" value="CHN">China</option>
<option role="option" value="CIV">CÃ´te dâ€™Ivoire</option>
<option role="option" value="CMR">Cameroon</option>
<option role="option" value="COD">Congo, The Democratic Republic of the</option>
<option role="option" value="COG">Congo</option>
<option role="option" value="COK">Cook Islands</option>
<option role="option" value="COL">Colombia</option>
<option role="option" value="COM">Comoros</option>
<option role="option" value="CPV">Cape Verde</option>
<option role="option" value="CRI">Costa Rica</option>
<option role="option" value="CUB">Cuba</option>
<option role="option" value="CXR">Christmas Island</option>
<option role="option" value="CYM">Cayman Islands</option>
<option role="option" value="CYP">Cyprus</option>
<option role="option" value="CZE">Czech Republic</option>
<option role="option" value="DEU">Germany</option>
<option role="option" value="DJI">Djibouti</option>
<option role="option" value="DMA">Dominica</option>
<option role="option" value="DNK">Denmark</option>
<option role="option" value="DOM">Dominican Republic</option>
<option role="option" value="DZA">Algeria</option>
<option role="option" value="ECU">Ecuador</option>
<option role="option" value="EGY">Egypt</option>
<option role="option" value="ERI">Eritrea</option>
<option role="option" value="ESH">Western Sahara</option>
<option role="option" value="ESP">Spain</option>
<option role="option" value="EST">Estonia</option>
<option role="option" value="ETH">Ethiopia</option>
<option role="option" value="FIN">Finland</option>
<option role="option" value="FJI">Fiji Islands</option>
<option role="option" value="FLK">Falkland Islands</option>
<option role="option" value="FRA">France</option>
<option role="option" value="FRO">Faroe Islands</option>
<option role="option" value="FSM">Micronesia, Federated States of</option>
<option role="option" value="GAB">Gabon</option>
<option role="option" value="GBR">United Kingdom</option>
<option role="option" value="GEO">Georgia</option>
<option role="option" value="GHA">Ghana</option>
<option role="option" value="GIB">Gibraltar</option>
<option role="option" value="GIN">Guinea</option>
<option role="option" value="GLP">Guadeloupe</option>
<option role="option" value="GMB">Gambia</option>
<option role="option" value="GNB">Guinea-Bissau</option>
<option role="option" value="GNQ">Equatorial Guinea</option>
<option role="option" value="GRC">Greece</option>
<option role="option" value="GRD">Grenada</option>
<option role="option" value="GRL">Greenland</option>
<option role="option" value="GTM">Guatemala</option>
<option role="option" value="GUF">French Guiana</option>
<option role="option" value="GUM">Guam</option>
<option role="option" value="GUY">Guyana</option>
<option role="option" value="HKG">Hong Kong</option>
<option role="option" value="HMD">Heard Island and McDonald Islands</option>
<option role="option" value="HND">Honduras</option>
<option role="option" value="HRV">Croatia</option>
<option role="option" value="HTI">Haiti</option>
<option role="option" value="HUN">Hungary</option>
<option role="option" value="IDN">Indonesia</option>
<option role="option" value="IND">India</option>
<option role="option" value="IOT">British Indian Ocean Territory</option>
<option role="option" value="IRL">Ireland</option>
<option role="option" value="IRN">Iran</option>
<option role="option" value="IRQ">Iraq</option>
<option role="option" value="ISL">Iceland</option>
<option role="option" value="ISR">Israel</option>
<option role="option" value="ITA">Italy</option>
<option role="option" value="JAM">Jamaica</option>
<option role="option" value="JOR">Jordan</option>
<option role="option" value="JPN">Japan</option>
<option role="option" value="KAZ">Kazakstan</option>
<option role="option" value="KEN">Kenya</option>
<option role="option" value="KGZ">Kyrgyzstan</option>
<option role="option" value="KHM">Cambodia</option>
<option role="option" value="KIR">Kiribati</option>
<option role="option" value="KNA">Saint Kitts and Nevis</option>
<option role="option" value="KOR">South Korea</option>
<option role="option" value="KWT">Kuwait</option>
<option role="option" value="LAO">Laos</option>
<option role="option" value="LBN">Lebanon</option>
<option role="option" value="LBR">Liberia</option>
<option role="option" value="LBY">Libyan Arab Jamahiriya</option>
<option role="option" value="LCA">Saint Lucia</option>
<option role="option" value="LIE">Liechtenstein</option>
<option role="option" value="LKA">Sri Lanka</option>
<option role="option" value="LSO">Lesotho</option>
<option role="option" value="LTU">Lithuania</option>
<option role="option" value="LUX">Luxembourg</option>
<option role="option" value="LVA">Latvia</option>
<option role="option" value="MAC">Macao</option>
<option role="option" value="MAR">Morocco</option>
<option role="option" value="MCO">Monaco</option>
<option role="option" value="MDA">Moldova</option>
<option role="option" value="MDG">Madagascar</option>
<option role="option" value="MDV">Maldives</option>
<option role="option" value="MEX">Mexico</option>
<option role="option" value="MHL">Marshall Islands</option>
<option role="option" value="MKD">Macedonia</option>
<option role="option" value="MLI">Mali</option>
<option role="option" value="MLT">Malta</option>
<option role="option" value="MMR">Myanmar</option>
<option role="option" value="MNG">Mongolia</option>
<option role="option" value="MNP">Northern Mariana Islands</option>
<option role="option" value="MOZ">Mozambique</option>
<option role="option" value="MRT">Mauritania</option>
<option role="option" value="MSR">Montserrat</option>
<option role="option" value="MTQ">Martinique</option>
<option role="option" value="MUS">Mauritius</option>
<option role="option" value="MWI">Malawi</option>
<option role="option" value="MYS">Malaysia</option>
<option role="option" value="MYT">Mayotte</option>
<option role="option" value="NAM">Namibia</option>
<option role="option" value="NCL">New Caledonia</option>
<option role="option" value="NER">Niger</option>
<option role="option" value="NFK">Norfolk Island</option>
<option role="option" value="NGA">Nigeria</option>
<option role="option" value="NIC">Nicaragua</option>
<option role="option" value="NIU">Niue</option>
<option role="option" value="NLD">Netherlands</option>
<option role="option" value="NOR">Norway</option>
<option role="option" value="NPL">Nepal</option>
<option role="option" value="NRU">Nauru</option>
<option role="option" value="NZL">New Zealand</option>
<option role="option" value="OMN">Oman</option>
<option role="option" value="PAK">Pakistan</option>
<option role="option" value="PAN">Panama</option>
<option role="option" value="PCN">Pitcairn</option>
<option role="option" value="PER">Peru</option>
<option role="option" value="PHL">Philippines</option>
<option role="option" value="PLW">Palau</option>
<option role="option" value="PNG">Papua New Guinea</option>
<option role="option" value="POL">Poland</option>
<option role="option" value="PRI">Puerto Rico</option>
<option role="option" value="PRK">North Korea</option>
<option role="option" value="PRT">Portugal</option>
<option role="option" value="PRY">Paraguay</option>
<option role="option" value="PSE">Palestine</option>
<option role="option" value="PYF">French Polynesia</option>
<option role="option" value="QAT">Qatar</option>
<option role="option" value="REU">RÃ©union</option>
<option role="option" value="ROM">Romania</option>
<option role="option" value="RUS">Russian Federation</option>
<option role="option" value="RWA">Rwanda</option>
<option role="option" value="SAU">Saudi Arabia</option>
<option role="option" value="SDN">Sudan</option>
<option role="option" value="SEN">Senegal</option>
<option role="option" value="SGP">Singapore</option>
<option role="option" value="SGS">South Georgia and the South Sandwich Islands</option>
<option role="option" value="SHN">Saint Helena</option>
<option role="option" value="SJM">Svalbard and Jan Mayen</option>
<option role="option" value="SLB">Solomon Islands</option>
<option role="option" value="SLE">Sierra Leone</option>
<option role="option" value="SLV">El Salvador</option>
<option role="option" value="SMR">San Marino</option>
<option role="option" value="SOM">Somalia</option>
<option role="option" value="SPM">Saint Pierre and Miquelon</option>
<option role="option" value="STP">Sao Tome and Principe</option>
<option role="option" value="SUR">Suriname</option>
<option role="option" value="SVK">Slovakia</option>
<option role="option" value="SVN">Slovenia</option>
<option role="option" value="SWE">Sweden</option>
<option role="option" value="SWZ">Swaziland</option>
<option role="option" value="SYC">Seychelles</option>
<option role="option" value="SYR">Syria</option>
<option role="option" value="TCA">Turks and Caicos Islands</option>
<option role="option" value="TCD">Chad</option>
<option role="option" value="TGO">Togo</option>
<option role="option" value="THA">Thailand</option>
<option role="option" value="TJK">Tajikistan</option>
<option role="option" value="TKL">Tokelau</option>
<option role="option" value="TKM">Turkmenistan</option>
<option role="option" value="TMP">East Timor</option>
<option role="option" value="TON">Tonga</option>
<option role="option" value="TTO">Trinidad and Tobago</option>
<option role="option" value="TUN">Tunisia</option>
<option role="option" value="TUR">Turkey</option>
<option role="option" value="TUV">Tuvalu</option>
<option role="option" value="TWN">Taiwan</option>
<option role="option" value="TZA">Tanzania</option>
<option role="option" value="UGA">Uganda</option>
<option role="option" value="UKR">Ukraine</option>
<option role="option" value="UMI">United States Minor Outlying Islands</option>
<option role="option" value="URY">Uruguay</option>
<option role="option" value="USA">United States</option>
<option role="option" value="UZB">Uzbekistan</option>
<option role="option" value="VAT">Holy See (Vatican City State)</option>
<option role="option" value="VCT">Saint Vincent and the Grenadines</option>
<option role="option" value="VEN">Venezuela</option>
<option role="option" value="VGB">Virgin Islands, British</option>
<option role="option" value="VIR">Virgin Islands, U.S.</option>
<option role="option" value="VNM">Vietnam</option>
<option role="option" value="VUT">Vanuatu</option>
<option role="option" value="WLF">Wallis and Futuna</option>
<option role="option" value="WSM">Samoa</option>
<option role="option" value="YEM">Yemen</option>
<option role="option" value="YUG">Yugoslavia</option>
<option role="option" value="ZAF">South Africa</option>
<option role="option" value="ZMB">Zambia</option>
<option role="option" value="ZWE">Zimbabwe</option>
</select>
</td>
</tr>
<tr rowpos="17" class="FormData" id="tr_HomePhone">
    <td class="CaptionTD">Home Phone</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="HomePhone" name="HomePhone" role="textbox" class="FormElement ui-widget-content ui-corner-all"></td>
</tr>
<tr style="display:none" rowpos="18" class="FormData" id="tr_Extension">
    <td class="CaptionTD">Extension</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="Extension" name="Extension" role="textbox" class="FormElement ui-widget-content ui-corner-all"></td>
</tr>
<tr rowpos="19" class="FormData" id="tr_Photo">
    <td class="CaptionTD">Photo</td>
    <td class="DataTD">&nbsp;<input type="text" size="30" id="Photo" name="Photo" role="textbox" class="FormElement ui-widget-content ui-corner-all"></td>
</tr>
<tr class="FormData">
    <td class="CaptionTD ui-widget-content" colspan="100%">
        <div class="form_group_header"><strong>Optional Info</strong></div>
    </td>
</tr>
<tr rowpos="20" class="FormData" id="tr_Notes">
    <td class="CaptionTD">Notes</td>
    <td class="DataTD">

        <textarea cols="42" rows="6" size="30" id="Notes" name="Notes" role="textbox" multiline="true" class="FormElement ui-widget-content ui-corner-all" style=""></textarea>
    </td>
</tr>
<tr rowpos="21" class="FormData" id="tr_Shift">
    <td class="CaptionTD">Preferred Shift</td>
    <td class="DataTD">
        &nbsp;
                        <span class="FormElement">
                            <div class="input_list customelement" id="Shift" name="Shift"><input type="checkbox" name="Shift[]" value="Regular">Regular<br><input type="checkbox" name="Shift[]" value="Gravy Yard" checked="checked">Gravy Yard<br></div>
                        </span>
    </td>
</tr>
<tr rowpos="22" class="FormData" id="tr_IsActive">
    <td class="CaptionTD">Active?</td>
    <td class="DataTD">&nbsp;<input type="checkbox" checked="" value="1" offval="0" id="IsActive" name="IsActive" role="checkbox" class="FormElement"></td>
</tr>
<tr rowpos="23" class="FormData" id="tr__realperson">
    <td class="CaptionTD">Are you human?</td>
    <td class="DataTD">
        &nbsp;
        <div class="realperson-challenge">
            <div class="realperson-text">&nbsp;*****&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;******&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*******&nbsp;&nbsp;*******&nbsp;&nbsp;<br>*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;**&nbsp;&nbsp;&nbsp;**&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;*&nbsp;*&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;****&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;****&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>*&nbsp;&nbsp;&nbsp;*&nbsp;*&nbsp;&nbsp;*&nbsp;*&nbsp;*&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>*&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;**&nbsp;&nbsp;&nbsp;**&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>&nbsp;****&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;******&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*&nbsp;&nbsp;*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*******&nbsp;&nbsp;<br></div>
            <div class="realperson-regen">Click to change</div>
        </div>
        <input type="hidden" class="realperson-hash" name="_realpersonHash" value="-887239127"><input type="text" id="_realperson" name="_realperson" role="textbox" class="FormElement ui-widget-content ui-corner-all hasRealPerson">
    </td>
</tr>
<tr class="FormData" style="display:none">
    <td class="CaptionTD"></td>
    <td colspan="1" class="DataTD"><input class="FormElement" id="id_g" type="text" name="employees_id" value="9"></td>
</tr>
</tbody>
</table>
</form>


<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
    // convert TABLE to LIST method 1
    function convertToList(element) {
        var list = $("<ul/>");
        $(element).find("tr").each(function() {
            var p = $(this).children().map(function() {
                return "<p>" + $(this).html() + "</p>";
            });
            list.append("<li>" + $.makeArray(p).join("") + "</li>");
        });
        $(element).replaceWith(list);
    }

    // convert TABLE to LIST method 2
    function convertToList2() {
        var $inputs = jQuery('#FrmGrid_employees :input');
        var values = {};
        $inputs.each(function() {
            console.log(values[this.name] = jQuery(this).val());

        });

        $('table').replaceWith
            (
                $('table').html()
                    .replace(/<tbody/gi, "<ul id='table'")
                    .replace(/<tr/gi, "<li")
                    .replace(/<\/tr>/gi, "</li>")
                    .replace(/<td/gi, "<p")
                    .replace(/<\/td>/gi, "</p>")
                    .replace(/<th/gi, "<p")
                    .replace(/<\/th>/gi, "</p>")
                    .replace(/<\/tbody/gi, "<\/ul")
                    .replace(/&nbsp;/gi, "")
            );
    }
   convertToList2();

</script>

<link rel="stylesheet" type="text/css" media="screen" href="/phpDatabaseForm/css/pdbf_li.css">


</body>
</html>