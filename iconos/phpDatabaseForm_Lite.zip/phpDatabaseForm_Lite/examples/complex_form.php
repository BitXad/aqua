<?php
require_once("../conf.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>phpDatabaseForm - Complex Form Layout</title>
</head>
<body>

<?php
// when not using default single column layout, it is recommended to list the fields
// in the same order of to be displayed on the form, from top to bottom, left to right
$dbForm = new C_DatabaseForm("SELECT * FROM Employees", "EmployeeID", "Employees");

// change column titles
$dbForm -> set_label("EmployeeID", "Employee ID");
$dbForm -> set_label("LastName", "Last Name");
$dbForm -> set_label("FirstName", "First Name");
$dbForm -> set_label("BirthDay", "DOB");
$dbForm -> set_label("PostalCode", "Postal Code");
$dbForm -> set_label("HomePhone", "US Home Phone");
$dbForm -> set_label("ReportsTo", "Reports To");
$dbForm -> set_label("TitleOfCourtesy", "Suffix");
$dbForm -> set_label("IsActive", "Active?");
$dbForm -> set_label("Shift", "Preferred Shift");
$dbForm -> set_label("SSN", "SSN # (if applicable)");

$dbForm -> set_hide("requiredDate");
$dbForm -> set_hide("Extension");
$dbForm -> set_hide("hireDate");


//$dbForm -> set_border('none');

$dbForm -> set_placeholder('Title', 'official job title');
$dbForm -> set_placeholder('TitleOfCourtesy', 'Mr., Ms., phD, Professor');
$dbForm -> set_placeholder('Email', 'name@example.com');

$dbForm -> set_readonly(array('EmployeeID, LastName'));
$dbForm -> set_required(array("LastName"));

$dbForm -> set_ctrltype('Notes', 'wysiwyg', 30, 40);
$dbForm -> set_ctrltype("Country", "autocomplete", "SELECT Code, Name FROM Country");
$dbForm -> set_ctrltype("ReportsTo", "select", "SELECT EmployeeID, LastName FROM Employees");
$dbForm -> set_ctrltype('Email', 'email');
$dbForm -> set_ctrltype('Gender', 'radio', 'M:Male;F:Female');
$dbForm -> set_ctrltype('IsActive', 'checkbox', '1:0');
$dbForm -> set_ctrltype('Shift', 'checkboxlist', 'Regular:Regular;Gravy Yard:Gravy Yard');
$dbForm -> set_ctrltype('SSN', 'password');
//$dbForm -> set_col_fileupload('Photo', '/phpDatabaseForm/examples/SampleImages/'); version 2

$dbForm -> set_editrule("SSN", "SSN_validate");
$dbForm -> set_maxlength("LastName", 8);

//$dbForm -> set_default('Title', 'N/A'); // default text only applies to new data entry

//$dbForm -> set_col_property("LastName", array("formoptions"=>array("rowpos"=>5,"colpos"=>2)));

/*
$dbForm -> set_col_property("EmployeeID", array("formoptions"=>array("rowpos"=>1,"colpos"=>1)));
$dbForm -> set_col_property("LastName", array("formoptions"=>array("rowpos"=>1,"colpos"=>2)));
$dbForm -> set_col_property("FirstName", array("formoptions"=>array("rowpos"=>2,"colpos"=>1)));
$dbForm -> set_col_property("BirthDay", array("formoptions"=>array("rowpos"=>2,"colpos"=>2)));
$dbForm -> set_col_property("PostalCode", array("formoptions"=>array("rowpos"=>3,"colpos"=>1)));
$dbForm -> set_col_property("HomePhone", array("formoptions"=>array("rowpos"=>3,"colpos"=>2)));
$dbForm -> set_col_property("ReportsTos", array("formoptions"=>array("rowpos"=>4,"colpos"=>1)));
*/

/*
 * // must set layout for each field when using set_layout due to HTML table.
 * // it calls set_col_property internally
 * $dbform -> set_layout('key1', row1, col1) -> set_layout('key2', row1, col2);
 * $dbfrom -> set_layout('key3', row2, col1) -> set_layout('key4', row1, col2);
 * $dbfrom -> set_layout('key5', row3, col1) -> set_layout('key6', row1, col2);
 *
 * // or auto multiple column layout, 1, 2...columns, when not specified, use single column
 * // it calls set_col_property
 * $dbfrom -> set_layoutauto(3); // 3 column layout
 */

$dbForm -> load_form(9);
$dbForm -> set_form_dimension(600);  // set width to 500 for table template
//$dbForm -> redirect_after_submit("http://stackoverflow.com");
$dbForm -> add_group_header("EmployeeID", "Basic Info");
$dbForm -> add_group_header("Email", "Contact Info");
$dbForm -> add_group_header("Notes", "Optional Info");
$dbForm -> add_tooltip("BirthDate", "Enter employee birth date"); // tooltip supports HTML as well
$dbForm -> add_captcha();

$dbForm -> set_mask("HomePhone", "(000)000-0000", "{placeholder: '(___)__-____'}");

$dbForm -> display();
?>


<script>
    jQuery(document).ready(function(){
        // TblGrid_employees
        /* setTimeout(function(){
         $("#tr_LastName").addClass("leftHalf");
         }, 2000)
         */
    });

    function SSN_validate(value, colname){
        var re = /^(\d{3}-?\d{2}-?\d{4}|XXX-XX-XXXX)$/;
        if(!re.test(value)){
            return [false, colname + " is invalid."];
        }else{
            return [true, ""];
        }
    }

    // convert TABLE to LIST method 1
    function convertToList(element) {
        var list = $("<ul/>");
        $(element).find("tr").each(function() {
            var p = $(this).children().map(function() {
                return "<p>" + $(this).html() + "</p>";
            });
            list.append("<li>" + $.makeArray(p).join("") + "</li>");
        });
        $(element).replaceWith(list);
    }

    // convert TABLE to LIST method 2
    function convertToList2() {
        $('table').replaceWith
            (
                $('table').html()
                    .replace(/<tbody/gi, "<ul id='table'")
                    .replace(/<tr/gi, "<li")
                    .replace(/<\/tr>/gi, "</li>")
                    .replace(/<td/gi, "<p")
                    .replace(/<\/td>/gi, "</p>")
                    .replace(/<th/gi, "<p")
                    .replace(/<\/th>/gi, "</p>")
                    .replace(/<\/tbody/gi, "<\/ul")
                    .replace(/&nbsp;/gi, "")
            );
    }
</script>

<link rel="stylesheet" type="text/css" media="screen" href="/phpDatabaseForm/css/pdbf_li.css">

<div style="text-align:center">
    <a href="simple_form.php">Simple form example</a>
</div>

</body>
</html>