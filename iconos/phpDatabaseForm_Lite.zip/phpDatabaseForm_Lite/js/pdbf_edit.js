//  for custom edit rules and options
var pdbf = {
    validateEmail: function(value, colname) {
        var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if(!re.test(value)){
            return [false, colname + " has an invalid email address."];
        }else{
            return [true, ""];
        }
    },

    // this should return DOM element.
    radioElement: function(value, editoptions) {
        // ctrlElm = "<ul class='radiolist'>";
        ctrlElm = "<div class='input_list'>";
        kvPair = editoptions.value.split(";");  // a:apple;b:boy...
        for(var i=0; i<kvPair.length;i++){
            tmp = kvPair[i];
            kv = tmp.split(":");
            ctrlElm += '<input type="radio" id="'+editoptions.id+'" name="'+editoptions.id+'" value="' + kv[0] + '" ' + (value===kv[0]?'checked="checked"':'') +' />' + kv[1] + '<br />';
        }
        ctrlElm += "</div>";
        // ctrlElm += "</ul>";

        return  ctrlElm;

    },

    radioValue: function(elm, operation, value) {
        frmId = elm.closest('form').prop('id');
        if (operation === 'get') {
         /*   console.log(elm);
            console.log(operation);
            console.log(value);
            console.log(elm.prop('id'));
            console.log('"#'+ elm.closest('form').prop('id')+'"');
            console.log($('input[name='+elm.prop('id')+']:checked', '#'+ frmId).val());
        */
            if($('input[name='+elm.prop('id')+']:checked', '#'+ frmId)){
                return $('input[name='+elm.prop('id')+']:checked', '#'+ frmId).val(); // return $(elm).val();
            }else{
                return "nothing";
            }
        } else if (operation === 'set') {
            if ($(elm).is(':checked') === false) {
                $(elm).filter('[value="' + value + '"]').prop('checked', true);
            }
        }
    },

    // this should return DOM element.
    checkboxlistElement: function(value, editoptions) {
        // ctrlElm = "<ul class='checkboxlist'>";
        ctrlElm = "<div class='input_list'>";
        kvPair = editoptions.value.split(";");  // a:apple;b:boy...
        for(var i=0; i<kvPair.length;i++){
            tmp = kvPair[i];
            kv = tmp.split(":");
            ctrlElm += '<input type="checkbox" name="' + editoptions.id + '[]" value="' + kv[0] + '" ' + (value===kv[0]?'checked="checked"':'') +' />' + kv[1] + '<br />';
        }
        ctrlElm += "</div>";
        //ctrlElm += "</ul>";

        return  ctrlElm;

    },

    checkboxlistValue: function(elm, operation, value) {
        frmId = elm.closest('form').prop('id');
        cList = '';
        if (operation === 'get') {
            $('input[name="'+elm.prop('id')+'[]"]:checked','#'+ frmId).each(function () {
                cList += $(this).val() + ',';
            });
            return cList.slice(0, - 1); // remove last ","
        }else if (operation === 'set'){
            kvPair = value.split(",");  // value stored in database
            for(var i=0; i<kvPair.length;i++){
                if ($("input[name='" + elm.prop("id") + "[]']").filter('[value="' + kvPair[i] + '"]').is(':checked') === false) {
                    $("input[name='" + elm.prop("id") + "[]']").filter('[value="' + kvPair[i] + '"]').prop('checked', true); // doesn't work - probably due to the same input[checkbox] id.
                 // $("input[name='Shift[]']").filter('[value="Regular"]').prop('checked', true); // this works when manually executing in console
                }
            }

        }
    },

    // users can easily modify this function to bypass Captcha
    // it's recommended to add a SESSION var in jquery.realperson.php to store Captcha validation status.
    validateCaptcha: function(value, colname){
        // console.log($("input[name='_realpersonHash']").val());
        console.log(location);
        console.log(document.referer);
        var isHuman = null;
        var resp = '';
        var captchaData = {_realperson:value, _realpersonHash:$("input[name='_realpersonHash']").val()};
        $.ajax({
            url: '/phpDatabaseForm/js/realperson/jquery.realperson.php', // TODO use relative path
            type: 'POST',
            data: captchaData,
            async: false,  // Set async to true, or isHuman may or may not get a boolean value
            success: function(response) {
                resp = response;
                if(response  == 'OK'){
                    isHuman = true;
                }else{
                    isHuman = false;
                }
            }
        });
        if(isHuman){
            return [true, resp];
        }else{
            return [false, resp];
        }
    }

};
